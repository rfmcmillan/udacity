import time
import random
weapons = ["blunderbuss", "longsword", "rapier", "whip"]
weapon = random.choice(weapons)
items = []


def print_pause(message_to_print):
    print(message_to_print, flush=True)
    time.sleep(2)


def intro():
    print_pause("You open your eyes. Where are you? You look around to see" +
                " a vast desert.")
    print_pause("You are vaguely aware that something nasty is lurking.")
    print_pause("What could it be?")


def hut_or_portal():
    print_pause("You see a hut and a time portal.")
    print_pause("Enter 1 to enter the hut.")
    print_pause("Enter 2 to enter the time portal.")
    print_pause("What would you like to do?")
    while True:
        choice = input("(Please enter 1 or 2).\n")
        if choice == '1':
            house()
            break
        elif choice == '2':
            cave()
            break
        else:
            print_pause("Sorry, I don't understand.")


def play_again():
    print_pause("Would you like to play again?")
    while True:
        replay = input("Please enter 1 for 'Yes' or 2 for 'No'\n")
        if replay == '1':
            play_game()
        elif replay == '2':
            break
        else:
            print_pause("Sorry, I don't understand.")


def fight():
    if weapon in items:
        print_pause("You brandish your " + weapon + " and vanquish your foe.")
        print_pause("You head to the beast's fridge, find some milk, pour " +
                    "some into a glass")
        print_pause("and drink down the sweet milk of victory.")
        print_pause("Congratulations! You win!")

        play_again()
    else:
        print_pause("You try to fight the beast but it is too strong. " +
                    "It vanquishes you. Game Over. You lose.")
        play_again()


def cave():
    print_pause("You step into the time portal and find a " + weapon + ".")
    print_pause("You exit back out into the desert.")
    items.append(weapon)
    hut_or_portal()


def field():
    print_pause("You scamper back to the relative safety of the desert to" +
                " regroup.")
    hut_or_portal()


def house():
    print_pause("You enter the hut and see sitting there in an armchair, " +
                "a wicked beast.\n")
    print_pause("Do you fight or run?")
    while True:
        choice = input("(Press 1 to fight or 2 to run)\n")
        if choice == "1":
            fight()
            break
        elif choice == "2":
            field()
            break
        else:
            print_pause("Sorry, I don't understand.")


def play_game():
    intro()
    hut_or_portal()


play_game()
