//sets global variables for the widthHeightInput form and the pixelGrid table
const widthHeightInput = document.querySelector('.widthHeightInput');
const pixelGrid = document.querySelector('.pixelGrid');


// Defines a function called makeGrid that allows for the change in size
// and the change in color

function makeGrid() {
    let gridHeight = document.querySelector('.inputHeight').value;
    let gridWidth = document.querySelector('.inputWidth').value;

// removes the previous pixelGrid table when submit button is clicked

    while (pixelGrid.firstChild) {
    pixelGrid.removeChild(pixelGrid.firstChild);
    }

// nested loop for making the pixelGrid that uses the width and height inputs

    for (let i = 1; i <= gridHeight; i++) {
        let gridRow = document.createElement('tr');
        pixelGrid.appendChild(gridRow);
        for (let j = 1; j <= gridWidth; j++) {
            let gridCell = document.createElement('td');
            gridRow.appendChild(gridCell);
            gridCell.addEventListener('click', function() {
                const color = document.querySelector('.colorInput').value;
                this.style.backgroundColor = color;
            })
        }
    }
}

// makeGrid function call for when the page is first loaded

makeGrid();

// makeGrid function call for when the submit button is clicked
// prevents the automatic reloading of page when submit is clicked

widthHeightInput.addEventListener('submit', function(event) {
    event.preventDefault();
    makeGrid();
});
